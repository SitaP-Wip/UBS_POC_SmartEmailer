﻿import React, { useState } from 'react'
import { List, ListItem } from '@fluentui/react-northstar'


const TemplateItem = (props) => {
    
    const [state, setState] = React.useState({ selectedIndex: '' })
    return (
        <ListItem
            key={props.template.header}
            header={props.template.header} content={props.template.content} contentMedia={props.template.contentMedia}
            headerMedia={props.template.headerMedia} endMedia={props.template.endMedia} pinned={props.template.pinned} frequentlyUsed={props.template.frequentlyUsed} 
            selectable
            selected={props.selected}
                onClick={(e) => {
                    //alert(
                    //    `Showing preview for "${state.selectedIndex}"`,
                    //)
                    setState({
                        selectedIndex: props.template.header,
                    })
                    props.changeTemplatePreviewData(props.template.header)
                }}
                truncateHeader={true}
                truncateContent={true}
            />
    )
}

export default TemplateItem

