﻿import React from 'react';
import { Suspense } from 'react';
import { BrowserRouter, Route, Switch } from 'react-router-dom';
//import ErrorPage from "../components/error-page/error-page";
//import SignInPage from "../components/sign-in-page/sign-in-page";
//import SignInSimpleStart from "../components/sign-in-page/sign-in-simple-start";
//import SignInSimpleEnd from "../components/sign-in-page/sign-in-simple-end";
import ComposeEmail from './ComposeEmail';
import SavedTemplate from './SavedTemplate';
import Personalize from './Personalize';


function AppRoute() {

    return (
        <Suspense fallback={<></>}>
            <BrowserRouter>
                <Switch>
                    <Route exact path="/ComposeEmail" render={(props) => <ComposeEmail isEditable={true} />} />
                    <Route exact path="/SavedTemplates" render={(props) => <SavedTemplate />} />
                    <Route exact path="/SentItems" render={(props) => <SavedTemplate />} />
                    <Route exact path="/Personalize" render={(props) => <Personalize />} />
                </Switch>
            </BrowserRouter>
        </Suspense>
    );
}

export default AppRoute; 
