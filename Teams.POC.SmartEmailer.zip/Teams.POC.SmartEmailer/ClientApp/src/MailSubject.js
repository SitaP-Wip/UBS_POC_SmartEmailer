﻿import React, { Component } from 'react';
import { Input } from '@fluentui/react-northstar';
function MailSubject(props) {
    return (
        <Input placeholder="Subject" value={props.mailSubject} fluid />
 );
}
export default MailSubject;