﻿import React, { Component } from 'react';
import { Text, Flex, Segment } from '@fluentui/react-northstar'
import { EmailIcon } from '@fluentui/react-icons-northstar'

function NoPreview() {
    return (
        <Flex column gap="gap.smaller">
            <div align="center"><EmailIcon rotate={0} size='largest' /></div>
            <Text content="Select an item to read" size="large" weight="semibold" />
            <Text content="Nothing is selected" size="medium" weight="regular" align="center" />
        </Flex>
    );
}
export default NoPreview;