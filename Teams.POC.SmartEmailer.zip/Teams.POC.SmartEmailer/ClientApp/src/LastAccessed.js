﻿import React, { Component } from 'react';
import { Text } from '@fluentui/react-northstar'

function LastAccessed(props) {
    return (
        <Text content={props.value} size="small" timestamp weight="regular" />
    );
}
export default LastAccessed;
