﻿import React, { useState} from 'react'
import { List, } from '@fluentui/react-northstar'


const ListExample = (props) => {
   
    const [state, setState] = React.useState({ selectedIndex: props.selectedTemplateIndex })
    return (
        <div style={{ width: '19rem'}} >
                <List
                    selectable
                    selectedIndex={state.selectedIndex}
                    onSelectedIndexChange={(e, newProps) => {
                        //alert(
                        //    `Showing preview for "${newProps.selectedIndex}"`,
                        //)
                        setState({
                            selectedIndex: newProps.selectedIndex,
                        })
                        props.changeTemplatePreviewData(newProps.selectedIndex)
                    }}
                    items={props.templates}
                    truncateHeader={true}
                    truncateContent={true}
                />
            </div>

        )
    //}
}

export default ListExample

