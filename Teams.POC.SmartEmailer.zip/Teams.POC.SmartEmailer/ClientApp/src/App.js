import React, { Component, useState, useEffect, useRef } from 'react';
import { Provider, teamsTheme, Accordion, Button, ButtonGroup, Flex, Menu, menuAsToolbarBehavior, tabListBehavior, Dropdown, Grid, Box, Segment, Text, Label, FlexItem, Divider, EditIcon, ParticipantAddIcon, Input, Attachment, CalendarIcon, SyncIcon, ContentIcon, Checkbox, Datepicker, WordColorIcon, ExcelColorIcon, PowerPointColorIcon, ComposeIcon, ChatMessage, UserBlurIcon } from '@fluentui/react-northstar'
import { ThumbtackIcon, ThumbtackSlashIcon, MoreIcon, TrashCanIcon, EmailIcon } from '@fluentui/react-icons-northstar'
import logo from './logo.svg';
import './App.css';
import { useTeams, checkInTeams } from "msteams-react-base-component";
import * as microsoftTeams from "@microsoft/teams-js";

import AppRoute from './SERouter'
import ComposeEmail from './ComposeEmail'
import SavedTemplate from './SavedTemplate';

function App(props) {
    const [{ inTeams, theme }] = useTeams({ initialTheme: 'default' });
    const [state, setState] = useState({ theme: '' });
    const [isTeams, setIsTeams] = useState(false);
    const [tab, setTab] = useState('Compose Email');
    //const [tab, setTab] = useState('Saved Templates');
    //const menuInput = useRef();
    useEffect(() => {
        if (inTeams === true) {
            setIsTeams(true);
        } else {
            if (inTeams !== undefined) {
                setIsTeams(false);
            }
        }
    }, [inTeams]);

    const items = [
        {
            key: 'composeEmail',
            content: <Text content="Compose Email" size="regular" weight="regular" />,
        },
        {
            key: 'savedTemplates',
            content: <Text content="Smart Templates" size="regular" weight="regular" />
        },
        {
            key: 'smartDrafts',
            content: <Text content="Smart Drafts" size="regular" weight="regular" />
        },
        {
            key: 'sentItems',
            content: <Text content="Smart Sent Items" size="regular" weight="regular" />,
        },
        {
            key: 'deletedItems',
            content: <Text content="Smart Deleted Items" size="regular" weight="regular" />,
        }
    ]
    const loadMenuContent = (e) => {
        if (tab == 'Compose Email') {
            setTab('Saved Templates');
        }
        else if (tab == 'Saved Templates') {
            setTab('Compose Email');
        }
        else if (tab == 'Sent Items') {
            setTab('Sent Items');
        }
    }
    useEffect(() => {
        microsoftTeams.initialize();
        microsoftTeams.getContext((context) => {
            let built_in_theme = context.theme || "";
            setState({ theme: built_in_theme })
        });

        microsoftTeams.registerOnThemeChangeHandler((theme) => {
            setState({
                theme: theme,
            }, () => {
                this.forceUpdate();
            });
        });
    }, [])
   
    const setThemeComponent = () => {
        
            return (
                <Provider theme={theme}>
                    <>
                        <Flex row gap="gap.small" fluid styles={{ backgroundColor: 'brand', paddingTop: '0.5rem', paddingBottom: '0', paddingLeft: '1rem' }}>
                            <EmailIcon size="larger" />
                            <Text content="Smart Email" size="large" weight="bold" />
                            <Menu
                                defaultActiveIndex={0}
                                items={items}
                                onActiveIndexChange={loadMenuContent}
                                primary
                                accessibility={tabListBehavior}
                                aria-label="Today's events"
                                styles={{ paddingLeft: '1rem', border: 'none' }}
                                fluid
                            />
                        </Flex>
                    </>
                    <Divider />
                    {getCurrentMenuContent()}
                </Provider>
            );
    }
    
    const getCurrentMenuContent = () => {
        if (tab == 'Compose Email')
            return <ComposeEmail isEditable={true} />;
        else if (tab == 'Saved Templates')
            return <SavedTemplate />;
        else
            return <SavedTemplate />;
    }
    const getAppDom = () => {
        return (
            <div className="app-container">
                <AppRoute />
            </div>
        );
    }

    return (
        <div>
            {setThemeComponent()}
        </div>
        );
}

export default App;