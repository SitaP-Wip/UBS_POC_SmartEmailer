﻿import React, { Component } from 'react';
import { Accordion} from '@fluentui/react-northstar'
import List from "./List";
import TemplateItem from "./TemplateItem";
import FilterPanel from './FilterPanel';

function SavedTemplatesSplitScreen0(props) {

    const getTemplateItem = (template, index) => {
        return <TemplateItem template={template} changeTemplatePreviewData={props.changeTemplatePreviewData} selected={props.currentTemplate.selectedTemplate == template.header}/>
    }
    //const pinnedTemplates = props.templates.filter(template => template.pinned == true).map(getTemplateItem)
    //const frequentlyUsedTemplates = props.templates.filter(template => template.frequentlyUsed == true).map(getTemplateItem)
    const myTemplates = props.templates.map(getTemplateItem)
    

    const items = [
        {
            id: 'pinned-templates',
            title: 'Pinned Templates',
            content: <List templates={props.templates.filter(template => template.pinned == true)} selectedTemplateIndex={0} changeTemplatePreviewData={props.changeTemplatePreviewData} />,
        },
        {
            id: 'frequently-used',
            title: 'Frequently Used',
            content: <List templates={props.templates.filter(template => template.pinned == true)} selectedTemplateIndex={0} changeTemplatePreviewData={props.changeTemplatePreviewData} />
        },
        {
            id: 'my-templates',
            title: 'My Templates',
            content: <List templates={props.templates.filter(template => template.pinned == true)} selectedTemplateIndex={0} changeTemplatePreviewData={props.changeTemplatePreviewData} />
        },
    ]
    const panels = [
        
        {
            title: 'Smart Sent Items',
            content: myTemplates,
        }
    ]
   
    return (
        <div>
            <FilterPanel />
            {/*<Tree aria-label="Custom title" items={items} accessibility={treeAsListBehavior} styles={{ marginTop: '2.7rem' }} />*/}
            {<Accordion defaultActiveIndex={[0, 1, 2]} panels={panels} styles={{ marginTop: '2.7rem', width: '19rem' }} />}
        </div>
    );
}
export default SavedTemplatesSplitScreen0;

