﻿import React from "react";
import ReactQuill from "react-quill";
import EditorToolbar, { modules, formats } from "./EditorToolbar";
import "react-quill/dist/quill.snow.css";
import "./Styles.css";

export const Editor = (props) => {
    const [state, setState] = React.useState({ value: props.messageBody });
    const handleChange = value => {
        setState({ value });
    };
    const MessageEditor = () => (
        <div className="text-editor">
            <EditorToolbar isReadOnly={props.isEditable} />
            <ReactQuill
                theme="snow"
                readOnly={props.isEditable}
                value={state.value}
                onChange={handleChange}
                placeholder={"Write something awesome..."}
                modules={modules}
                formats={formats}
            />
        </div>
    )
    return (
        <div className="text-editor">
            {props.isEditable ? <EditorToolbar /> : <EditorToolbar />}
            {props.isEditable ? <ReactQuill
                theme="snow"
                readOnly={!props.isEditable}
                value={state.value}
                onChange={handleChange}
                placeholder={"Write something awesome..."}
                modules={modules}
                formats={formats}   
            /> :
                <ReactQuill
                    theme="snow"
                    readOnly={!props.isEditable}
                    value={state.value}
                    onChange={handleChange}
                    placeholder={"Write something awesome..."}
                    modules={modules}
                    formats={formats}
                />
            }
        </div>

    );
};

export default Editor;