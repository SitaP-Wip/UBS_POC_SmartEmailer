﻿import React, { Component } from 'react';
import { Text } from '@fluentui/react-northstar'

function MailImportance(props) {
    return (
        <Text content="!" important size="medium" />
    );
}
export default MailImportance;
