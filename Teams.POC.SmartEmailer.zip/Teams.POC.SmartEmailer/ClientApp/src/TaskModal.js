﻿import React, { useState } from 'react'
import { Dialog, Button } from '@fluentui/react-northstar'
import { ThumbtackIcon, MoreIcon } from '@fluentui/react-icons-northstar'

function TaskModal(props) {
    return (
        <Dialog
            
            trigger={<Button content="Open a dialog" />}
        />
    );
}
export default TaskModal;