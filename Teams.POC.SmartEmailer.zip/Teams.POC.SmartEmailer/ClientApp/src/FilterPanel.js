﻿import React, { Component } from 'react';
import { Box, Flex, FlexItem, Segment, Text, Button, Divider, Menu, menuAsToolbarBehavior } from '@fluentui/react-northstar'
import { ThumbtackIcon, ThumbtackSlashIcon, MoreIcon, SearchIcon, TrashCanIcon, EditIcon } from '@fluentui/react-icons-northstar'

function FilterPanel() {
    const items = [
        {
            icon: (
                <SearchIcon
                    {...{
                        outline: true,
                    }}
                />
            ),
            key: 'search',
            'aria-label': 'Search',
        },
        {
            icon: (
                <MoreIcon
                    {...{
                        outline: true,
                    }}
                />
            ),
            key: 'menuButton2',
            'aria-label': 'More options',
            indicator: false,
            menu: {
                items: [
                    {
                        key: '5',
                        content: 'Edit',
                        icon: <EditIcon outline />,
                    },
                    {
                        key: '6',
                        content: 'Delete',
                        icon: <TrashCanIcon outline />,
                    },
                    {
                        key: 'divider',
                        kind: 'divider',
                    },
                ],
            },
        },
    ]
    const FlexBox = () => (
        <Flex gap="gap.gap.smaller">
            <Text content={"Filter"} size="large" weight="semibold" />
            <FlexItem push>
                <Menu
                    defaultActiveIndex={0}
                    items={items}
                    iconOnly
                    accessibility={menuAsToolbarBehavior}
                    aria-label="Compose Editor"
                />
            </FlexItem>
        </Flex>
        
        )
    return (
        <Flex styles={{ position: "fixed", zIndex: '999' }} fluid>
            <Segment key={"white"} content={<FlexBox />} styles={{ paddingBottom: '0.05rem', width: '19rem', borderBottom: '0.1rem', borderBottomColor: '#eee' }} />
        </Flex>

    );
}
export default FilterPanel;