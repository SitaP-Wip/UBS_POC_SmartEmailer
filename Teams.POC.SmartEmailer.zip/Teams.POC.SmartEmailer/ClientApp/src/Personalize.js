﻿import React, { Component } from 'react';
import { Flex, FlexItem, Input, Dropdown, Text, Button } from '@fluentui/react-northstar'

function Personalize(props) {
    const nameOrders = [
        'FirstName LastName',
        'LastName FirstName',
        'FirstName',
        'LastName',
    ]
    return (
        <Flex column gap="gap.medium" className="personalize-responsive">
            <Flex column gap="gap.small" >
                <Text content="Personalize subject:" weight="semibold" />
                <Flex row gap="gap.small">
                    <FlexItem grow>
                        <Input fluid placeholder="Hint text" inline />
                    </FlexItem>
                        <Dropdown
                            items={nameOrders}
                            placeholder="Name Order"
                            checkable
                            getA11ySelectionMessage={{
                                onAdd: item => `${item} has been selected.`,
                            }}
                        />
                </Flex>
                <Input fluid placeholder="If recipient does not exist in eco system:" inline />
            </Flex>
            <Flex column gap="gap.small" >
                <Text content="Personalize salutation:" weight="semibold" />
                <Flex row gap="gap.small">
                    <Input fluid placeholder="Hint text" inline />
                    <FlexItem size="size.quarter" push>
                        <Dropdown
                            items={nameOrders}
                            placeholder="Name Order"
                            checkable
                            getA11ySelectionMessage={{
                                onAdd: item => `${item} has been selected.`,
                            }}
                        />
                    </FlexItem>
                </Flex>
                <Input fluid placeholder="If recipient does not exist in eco system:" inline />
            </Flex>
            <Flex row gap="gap.small">
                <Button content="Cancel" fluid />
                <Button content="OK" primary fluid />
            </Flex>
        </Flex>
    );
}
export default Personalize;

