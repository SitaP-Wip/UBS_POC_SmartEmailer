﻿import React, { Component, useState, useEffect } from 'react';
import { Provider, Accordion, Button, ButtonGroup, Flex, Menu, menuAsToolbarBehavior, tabListBehavior, Dropdown, Grid, Box, Segment,Text, Label, FlexItem, Divider, EditIcon, ParticipantAddIcon, Input, Attachment, CalendarIcon, SyncIcon, ContentIcon, Checkbox, Datepicker, WordColorIcon, ExcelColorIcon, PowerPointColorIcon, ComposeIcon, ChatMessage, UserBlurIcon } from '@fluentui/react-northstar'
import { ThumbtackIcon, ThumbtackSlashIcon, MoreIcon, TrashCanIcon, EmailIcon } from '@fluentui/react-icons-northstar'
import List from "./List";
import App from "./App";
import SavedTemplatesSplitScreen0 from './SavedTemplatesSplitScreen0';
import MailPreview from './MailPreview';
import TemplateHeader from './TemplateHeader';
import LastAccessed from './LastAccessed';
import TemplateSubject from './TemplateSubject';
import MailImportance from './MailImportance';
import { useTeams } from "msteams-react-base-component";


function SavedTemplate() {
   
    const pinSelectedTemplate = (item) => {
    }
    const unpinItems = [
        {
            icon: <ThumbtackSlashIcon />,
            iconOnly: true,
            text: true,
            title: 'unpin',
            key: 'unpin',
            'aria-label': 'Search',
        },
        {
            icon: (
                <MoreIcon
                    {...{
                        outline: true,
                    }}
                />
            ),
            key: 'menuButton2',
            'aria-label': 'More options',
            indicator: false,
            menu: {
                items: [
                    {
                        key: '5',
                        content: 'See Analytics',
                        icon: <EditIcon outline />,
                    },
                    {
                        key: '6',
                        content: 'Delete',
                        icon: <TrashCanIcon outline />,
                    }
                ],
            },
        },
    ]
    const pinItems = [
        {
            icon: <ThumbtackIcon />,
            iconOnly: true,
            text: true,
            title: 'pin',
            key: 'pin',
            onClick: pinSelectedTemplate
        },
        {
            icon: (
                <MoreIcon
                    {...{
                        outline: true,
                    }}
                />
            ),
            iconOnly: true,
            text: true,
            title: 'more',
            key: 'more',
            'aria-label': 'More options',
            indicator: false,
            menu: {
                items: [
                    {
                        key: '5',
                        content: 'Edit',
                        icon: <EditIcon outline />,
                    },
                    {
                        key: '6',
                        content: 'Delete',
                        icon: <TrashCanIcon outline />,
                    }
                ],
            },
        }
        //{
        //    icon: <MoreIcon />,
        //    iconOnly: true,
        //    text: true,
        //    title: 'more',
        //    key: 'more',
        //},
    ]
    const pinActions = (
        <Menu
            items={unpinItems}
            iconOnly
            accessibility={menuAsToolbarBehavior}
            aria-label="Compose Editor"
        />
    );
    const actions = (
        <Menu
            items={pinItems}
            iconOnly
            accessibility={menuAsToolbarBehavior}
            aria-label="Compose Editor"
        />
    );
    
    const templateClick = (props) => {
     
    }
    const myTemplates = [
        {
            key: '0',
            header: "Sent Item 1",
            headerMedia: <LastAccessed value={"09:20 AM"} />,
            content: <TemplateSubject value={'Congratulations { FirstName } for completing the Delivery Management Foundation Module!'} />,
            contentMedia: <MailImportance value={'high'} />,
            endMedia: pinActions,
            pinned: true,
            frequentlyUsed: false,
        },
        {
            key: '1',
            header: "Sent Item 2",
            headerMedia: <LastAccessed value={"09:20 AM"} />,
            content: <TemplateSubject value={'Congratulations { FirstName } for completing the Delivery Management Foundation Module!'} />,
            contentMedia: <MailImportance value={'high'} />,
            endMedia: pinActions,
            pinned: true,
            frequentlyUsed: false,
        },
        {
            key: '2',
            header: "Sent Item 3",
            headerMedia: <LastAccessed value={"11:10 PM"} />,
            content: <TemplateSubject value={'Congratulations { FirstName } for completing the Delivery Management Foundation Module!'} />,
            contentMedia: '',
            endMedia: pinActions,
            pinned: true,
            frequentlyUsed: false,
        },
        {
            key: '3',
            header: "Sent Item 4",
            headerMedia: <LastAccessed value={"12:00 AM"} />,
            content: <TemplateSubject value={'Congratulations { FirstName } for completing the Delivery Management Foundation Module!'} />,
            contentMedia: <MailImportance value={'high'} />,
            endMedia: pinActions,
            pinned: true,
            frequentlyUsed: false,
        },
        {
            key: '4',
            header: <TemplateHeader value={"Sent Item 5"} />,
            headerMedia: <LastAccessed value={"4/12"} />,
            content: <TemplateSubject value={'Subject 1 - Test email 1 || Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample'} />,
            contentMedia: <MailImportance value={'high'} />,
            endMedia: actions,
            pinned: false,
            frequentlyUsed: true,
        },
        {
            key: '5',
            header: <TemplateHeader value={"Sent Item 6 truncate check lengthy text"} />,
            headerMedia: <LastAccessed value={"2/12"} />,
            content: <TemplateSubject value={'Subject 1 - Test email 1 || Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample'} />,
            contentMedia: '',
            endMedia: actions,
            pinned: false,
            frequentlyUsed: false,
        },
        {
            key: '6',
            header: <TemplateHeader value={"Sent Item 7"} />,
            headerMedia: <LastAccessed value={"30/11"} />,
            content: <TemplateSubject value={'Subject 1 - Test email 1 || Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample'} />,
            contentMedia: '',
            endMedia: actions,
            pinned: false,
            frequentlyUsed: true,
        },
        {
            key: '7',
            header: <TemplateHeader value={"Sent Item 8"} />,
            headerMedia: <LastAccessed value={"24/11"} />,
            content: <TemplateSubject value={'Subject 1 - Test email 1 || Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample'} />,
            contentMedia: <MailImportance value={'high'} />,
            endMedia: actions,
            pinned: false,
            frequentlyUsed: false,
        },
        {
            key: '8',
            header: <TemplateHeader value={"Sent Item 9"} />,
            headerMedia: <LastAccessed value={"24/11"} />,
            content: <TemplateSubject value={'Subject 1 - Test email 1 || Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample'} />,
            contentMedia: <MailImportance value={'high'} />,
            endMedia: actions,
            pinned: false,
            frequentlyUsed: false,
        },
        {
            key: '9',
            header: <TemplateHeader value={"Sent Item 10"} />,
            headerMedia: <LastAccessed value={"24/11"} />,
            content: <TemplateSubject value={'Subject 1 - Test email 1 || Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample'} />,
            contentMedia: <MailImportance value={'high'} />,
            endMedia: actions,
            pinned: false,
            frequentlyUsed: false,
        },
        {
            key: '10',
            header: <TemplateHeader value={"Sent Item 11"} />,
            headerMedia: <LastAccessed value={"24/11"} />,
            content: <TemplateSubject value={'Subject 1 - Test email 1 || Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample'} />,
            contentMedia: <MailImportance value={'high'} />,
            endMedia: actions,
            pinned: false,
            frequentlyUsed: false,
        },
        {
            key: '11',
            header: <TemplateHeader value={"Sent Item 12"} />,
            headerMedia: <LastAccessed value={"24/11"} />,
            content: <TemplateSubject value={'Subject 1 - Test email 1 || Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample'} />,
            contentMedia: <MailImportance value={'high'} />,
            endMedia: actions,
            pinned: false,
            frequentlyUsed: false,
        },
        {
            key: '12',
            header: <TemplateHeader value={"Sent Item 13"} />,
            headerMedia: <LastAccessed value={"24/11"} />,
            content: <TemplateSubject value={'Subject 1 - Test email 1 || Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample  Sample mail smaple sample sample'} />,
            contentMedia: <MailImportance value={'high'} />,
            endMedia: actions,
            pinned: false,
            frequentlyUsed: false,
        },
    ]
    
   
    const [currentTemplate, setCurrentTemplate] = React.useState({ selectedTemplate: '' })
    const [templates, setTemplates] = React.useState(myTemplates);
    //const [templatePreviewData, setTemplatePreviewData] = React.useState(templates.filter(template => template.key == 0)[0]);
    const [templatePreviewData, setTemplatePreviewData] = React.useState({});
    
    const changeTemplatePreviewData = (id) => {
        const templateData = templates.filter(template => template.header == id)[0];
        setTemplatePreviewData(templateData);
        setCurrentTemplate({ selectedTemplate: id })
    };

    
    const updateItem = (id, itemAttributes) => {
        var index = templates.findIndex(x => x.id === id);
       
        if (index !== -1)
            this.setState({
                items: [
                    ...this.state.items.slice(0, index),
                    Object.assign({}, this.state.items[index], itemAttributes),
                    ...this.state.items.slice(index + 1)
                ]
            });
    }
    //const pinTemplate = (id) = {
    //    //updateItem(id, { pinned: true });
    //};
    const savedTemplateComponents = [
        <SavedTemplatesSplitScreen0 changeTemplatePreviewData={(id) => changeTemplatePreviewData(id)} templates={templates} currentTemplate={currentTemplate}/>,
        <MailPreview templatePreviewData={templatePreviewData} />
    ]
    return (
        <Grid columns="1.2fr 5fr" content={savedTemplateComponents} />
    );
}

export default SavedTemplate;



//<Flex styles={{ padding: 0, margin: 0 }} >
//    <Segment content={<SavedTemplatesSplitScreen0 changeTemplatePreviewData={(id) => changeTemplatePreviewData(id)} templates={templates} currentTemplate={currentTemplate} />} />
//    <Segment content={<MailPreview templatePreviewData={templatePreviewData} />} />
//</Flex>

